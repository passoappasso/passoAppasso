function check(){

	var controllo=document.getElementById("sottotitoli");
	var testo=document.getElementById("subText");
	
	if(controllo.checked){
		testo.innerHTML="Sottotioli sotto ai video attivi";
		
	}
	else{
		testo.innerHTML="Sottotioli sotto ai video disattivi";
		
	}
	
	
}
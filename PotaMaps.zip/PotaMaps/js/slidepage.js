var init = function(){
	var oggetti = document.querySelectorAll('section');
	for (let i = 0; i < oggetti.length; i++)
		oggetti[i].style.background = "white";
	cssScrollSnapPolyfill();
	}
init();
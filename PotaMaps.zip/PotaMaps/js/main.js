window.onload = () => {
  'use strict';

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker
             .register('./sw.js');
  }
  document.getElementById("subText").innerHTML="Sottotioli sotto ai video disattivi";
	
}
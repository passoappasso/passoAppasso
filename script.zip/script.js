var chiave = "1L0ZbRin9vcl6S7sO7GMS4eTZrsO-W95iRAMYDl1B-1E";
  url = "https://spreadsheets.google.com/feeds/list/" + chiave + "/od6/public/basic?alt=json";
$.get({
  url: url,
  success: function(response) {
    var dati = response.feed.entry;
		for (i = 0; i < dati.length; i++) 
			alert(dati[i].title.$t+" "+dati[i].content.$t);
	}
});